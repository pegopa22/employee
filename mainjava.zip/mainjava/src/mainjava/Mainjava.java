
package mainjava;


public class Mainjava {

    
  
    public static void main(String[] args) {
        // Create two Employee objects
        Employee emp1 = new Employee("Yusra", "Mohammad", 2000.00);
        Employee emp2 = new Employee("Peshang", "Mohammad", 5000.00);

        // Display each employee's yearly salary
        System.out.println("NAME\t\t\tYEARLY SALARY");
        System.out.println("----\t\t\t-------------");
        System.out.printf("%s %s\t$%.2f%n", emp1.getFirstName(), emp1.getLastName(), emp1.getYearlySalary());
        System.out.printf("%s %s\t$%.2f%n", emp2.getFirstName(), emp2.getLastName(), emp2.getYearlySalary());

        // Increase salary by 10%
        emp1.increaseSalary(10);
        emp2.increaseSalary(10);

        // Display updated yearly salary
        System.out.println("\n10 Percent Salary Raised!! Yoohooooo!");
        System.out.println("NAME\t\t\tYEARLY SALARY");
        System.out.println("----\t\t\t-------------");
        System.out.printf("%s %s\t$%.2f%n", emp1.getFirstName(), emp1.getLastName(), emp1.getYearlySalary());
        System.out.printf("%s %s\t$%.2f%n", emp2.getFirstName(), emp2.getLastName(), emp2.getYearlySalary());
    }
}
    
    

